const userBaseUrl = "http://localhost:3030/users/";

const dataBaseUrl = "http://localhost:3030/data/";

export { userBaseUrl, dataBaseUrl };
